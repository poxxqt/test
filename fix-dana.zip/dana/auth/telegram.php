<?php
$telegram_id = "8054140139";
$id_bot = "8054140139:AAH4XJs3av52Lre45OcNjr3bSm9gghbhtZs";
?>
